/*
MacHeist game shell communication script

Revisions:
2012-06-22 / kalleboo / first logged version
*/

var is_uiwebview = /(iPhone|iPod|iPad).*AppleWebKit(?!.*Safari)/i.test(navigator.userAgent);

var shellVerbose = true;	// use this to toggle shell-related log on and off
							// modify it in a particular game to disable if needed

// displays resume/main menu when app returns from being backgrounded
var willDisplayResume = false;

function shellLog(msg)
	{
	if(shellVerbose)
		console.log(msg);
	}
	
WebViewCommsLib = {
	"callbacks": [],
	"requests": -1,
	"eventHandlers": {},
	
	"send": function(command, data, callback) {
	
		if (is_uiwebview) {
			WebViewCommsLib.requests++;
			shellLog('WebViewCommsLib: '+WebViewCommsLib.requests+' -> '+command+':'+data);
			
			if (callback != undefined) {
				WebViewCommsLib.callbacks[WebViewCommsLib.requests] = callback;
			}
			
			var form = document.createElement("form");
			form.action="mhwebview://mh."+command+"?"+WebViewCommsLib.requests;
			form.method="POST";
			
			var input = document.createElement("input");
			input.type = "text";
			input.name = "data";
			input.value = data;
			form.appendChild(input);
			
			form.submit();
		} else {
			shellLog('TESTING.WebViewCommsLib: 0 -> '+command+' (IGNORED)');
		}
	},
	
	"result":function(resultdict) {
		shellLog('WebViewCommsLib: '+resultdict.commandId+' <- '+JSON.stringify(resultdict));
		if (resultdict.commandId>WebViewCommsLib.requests) {
			shellLog('WebViewCommsLib: '+resultdict.commandId+' !! Got a callback FROM THE FUTURE! Ignoring...');
			return;
		}
		
		var call = WebViewCommsLib.callbacks[resultdict.commandId];
		if (call != undefined)
			call(resultdict.result);
		else
			shellLog('WebViewCommsLib: '+resultdict.commandId+' !! Result callback undefined. Ignoring...');
	},
	
	"event": function(data) {
		WebViewCommsLib.eventHandlers[data.name]();
	}
}

MHShellCalls = {
	
	"queueMessage":function(msg, data, onComplete)
		{
		if(!MHShellCalls.messageQueue)
			MHShellCalls.messageQueue = [];
		
		var obj = { msg:msg, data:data, onComplete:function(result) { MHShellCalls.nextMessage(); onComplete(result); } };
		
		// push the message onto the queue
		MHShellCalls.messageQueue.push(obj);
		
		// if nothing has been sent to the queue in the last 10ms, then send it immediately- otherwise wait
		if(!MHShellCalls.sentMessage)
			{
			shellLog("Sending next message immediately: " + msg);
			MHShellCalls.nextMessage();
			}
		else
			{
			shellLog("Queueing next message: " + msg);
			}
		},
	
	"nextMessage":function()
		{
		
		// if the queue is empty, stop!
		if(MHShellCalls.messageQueue.length == 0) {
			MHShellCalls.sentMessage = false;
 			return;
		}
		
		// get the next message in the queue
		var obj = MHShellCalls.messageQueue.shift();
		shellLog("  next message is " + obj.msg);
		
		// send the message
		MHShellCalls.sentMessage = true;
		WebViewCommsLib.send(obj.msg, obj.data, obj.onComplete);
		},
	
    "log": function(message) {
        if (is_uiwebview) {
	        MHShellCalls.queueMessage("log", message, function(){});
        } else {
        	shellLog(message);
        }
    },
    
	"playSound": function(filename,loop,soundId,useSystemSound,isFading,fadeInDuration) {
    	var obj = { fileName:filename, isLooping:loop, soundId:soundId, useSystemSound:useSystemSound, isFading:isFading, fadeInDuration:fadeInDuration };
        MHShellCalls.queueMessage("playSound", JSON.stringify(obj), function(){});
    },    
    "stopSound": function(soundId,fadeTime) {
    	var obj = { soundId:soundId, fadeTime:fadeTime };
        MHShellCalls.queueMessage("stopSound", JSON.stringify(obj), function(){});
    },
    
    "lockOrientation": function(value) {
        MHShellCalls.queueMessage("lockOrientation", value, function(){});
    },
        
    "debugControls": function(onComplete) {
        if (is_uiwebview) {
	        MHShellCalls.queueMessage("debugControls", "", onComplete);
        } else {
        	onComplete("ok");
        }
    },
    /*
    	options example: 
    	{
    		'filename': 'media/newsreel.mp4',
    		filenameIphoneHigh //retina iphone
    		filenameIphoneLow //iphone 3GS
    		
    		'startposter': 'media/backgroundstart.jpg',
    		startposterIphoneHigh //retina iphone
    		
    		'endposter': 'media/backgroundend.jpg',
    		endposterIphoneHigh //retina iphone
    		
    		//optional: if missing will be full screen
    		'x': 100,
    		'y': 100,
    		'width': 320,
    		'height': 480
    	}
    	
				

    */
    
    "displayResume": function()
    {
    	if ( !willDisplayResume )
    	{
    		return;
    	}
    	
    	// uncomment to allow displaying of resume screen
    	/*
    	MHShellCalls.log( 'MHShellCalls.displayResume()' );			
		if ( ig.game && ig.game.displayResume != undefined )
		{
			ig.game.displayResume();
		}
		*/
    },
    
    "playVideo": function(options,onComplete) {
        if (onComplete==undefined)
            onComplete = function(){};

		var videoFilename;
		var videoPosterStart;
		var videoPosterEnd;
				
		if (options.x==undefined) {
			options.x = "0px";
			options.y = "0px";
			options.width = "100%";
			options.height = "100%";
		} else {
			
			//var imageScale = ig.ua.renderRetina?1:.5;
			
			// html size is 480 for iPhone and iPhone 4, so we halve our sizes for those devices
			var imageScale = ig.ua.iPhone ? 0.5 : 1;
			
			options.x *= imageScale;
			options.y *= imageScale;
			options.width *= imageScale;
			options.height *= imageScale;
			
			options.x += 'px';
			options.y += 'px';
			options.width += 'px';
			options.height += 'px';
		}


		if (ig.ua.iPhone && ig.ua.renderRetina && options.filenameIphoneHigh)
			videoFilename = options.filenameIphoneHigh;
		else if (ig.ua.iPhone && options.filenameIphoneLow)
			videoFilename = options.filenameIphoneLow;
		else
			videoFilename = options.filename;

		if (ig.ua.iPhone && ig.ua.renderRetina && options.startposterIphoneHigh)
			videoPosterStart = options.startposterIphoneHigh;
		else if (ig.ua.iPhone && options.startposterIphoneLow)
			videoPosterStart = options.startposterIphoneLow;
		else 
			videoPosterStart = options.startposter;
			
		if (ig.ua.iPhone && ig.ua.renderRetina && options.endposterIphoneHigh)
			videoPosterEnd = options.endposterIphoneHigh;
		else if (ig.ua.iPhone && options.endposterIphoneLow)
			videoPosterEnd = options.endposterIphoneLow;
		else 
			videoPosterEnd = options.endposter;
			
		MHShellCalls.log('MHShellCalls: Playing video file '+videoFilename);
			
		var div = document.createElement('div');
		div.style.zIndex= "200";
		div.style.backgroundColor = 'black';
		div.style.backgroundImage = 'url('+videoPosterStart+')';
		div.style.backgroundSize = options.width+' '+options.height+'';
		div.style.position = "absolute";
		div.style.left = options.x;
		div.style.top = options.y;
		div.style.width = options.width;
		div.style.height = options.height;
		document.body.appendChild(div);

		if (options.overlay) {
			var overlayDiv = document.createElement('div');
			overlayDiv.style.zIndex= "150";
			overlayDiv.style.backgroundColor = 'transparent';
			overlayDiv.style.backgroundImage = 'url('+(ig.ua.renderRetina?options.overlay2x:options.overlay)+')';
			overlayDiv.style.backgroundSize = options.width+' '+options.height+'';
			overlayDiv.style.position = "absolute";
			overlayDiv.style.left = options.x;
			overlayDiv.style.top = options.y;
			overlayDiv.style.width = options.width;
			overlayDiv.style.height = options.height;
			document.body.appendChild(overlayDiv);
			MHShellCalls.overlayDiv = overlayDiv;
		}
        
		var tapDiv = document.createElement('div');
		tapDiv.style.zIndex= "300";
		tapDiv.style.background = 'transparent';
		tapDiv.style.position = "absolute";
		tapDiv.style.left = '0';
		tapDiv.style.top = '0';
		tapDiv.style.width = "100%";
		tapDiv.style.height = "100%";
		var tapEvent = function() {
			tapDiv.parentNode.removeChild(tapDiv);
			tapDiv.removed = true;
			if (ig.system)
				ig.system.startRunLoop.call(ig.system);
				
			// reassign return from background function since we have cancelled the video
			WebViewCommsLib.eventHandlers['returnedFromBackground'] = function()
			{
				MHShellCalls.displayResume();
			};
			
		};
		tapDiv.addEventListener('mousedown',tapEvent,false);
		tapDiv.addEventListener('touchend',tapEvent,false);
		document.body.appendChild(tapDiv);
        
        setTimeout(function() {
		MHShellCalls.unfreezeDisplay(function() {
			var video = document.createElement('video');
			video.src = videoFilename;
			video.setAttribute('webkit-playsinline','webkit-playsinline');
			video.style.position = "absolute";
			video.style.zIndex= "100";
			video.style.left= options.x;
			video.style.top= options.y;
			video.style.width = options.width;
			video.style.height = options.height;
			document.body.appendChild(video);
			
			WebViewCommsLib.eventHandlers['returnedFromBackground'] = function() {
				if (MHShellCalls.video) {
					//required on sim but not on device! MHShellCalls.video.currentTime -= 1;
					MHShellCalls.video.play();
				}
			};
			
			MHShellCalls.video = video;

			video.addEventListener('ended',function() {
				MHShellCalls.log('video ended');
				if (ig.system)
					ig.system.startRunLoop.call(ig.system);
				
				var div2 = document.createElement('div');
				div2.style.zIndex= "200";
				div2.style.backgroundColor = 'black';
				div2.style.backgroundImage = 'url('+videoPosterEnd+')';
				div2.style.backgroundSize = options.width+' '+options.height+'';
				div2.style.position = "absolute";
				div2.style.left = options.x;
				div2.style.top = options.y;
				div2.style.width = options.width;
				div2.style.height = options.height;
				document.body.appendChild(div2);
			
				if (overlayDiv && !overlayDiv.removed) {
					overlayDiv.removed = true;
					overlayDiv.parentNode.removeChild(overlayDiv);
				}
				
				//WebViewCommsLib.eventHandlers['returnedFromBackground'] = function(){};
				WebViewCommsLib.eventHandlers['returnedFromBackground'] = function()
				{
					MHShellCalls.displayResume();
				};
				
				setTimeout(function() {
					video.parentNode.removeChild(video);
					MHShellCalls.video = undefined;

					MHShellCalls.freezeDisplay(function() {
							div2.parentNode.removeChild(div2);
							onComplete();
					});
				},50);

				if (!tapDiv.removed)
					tapDiv.parentNode.removeChild(tapDiv);
	
			},false);

			video.addEventListener('playing',function() {
				setTimeout(function() {
					div.parentNode.removeChild(div);
				},250);
			});
			
			if (ig.system)
				ig.system.stopRunLoop.call(ig.system);
			
			video.play();
		});
		},250);

        //MHShellCalls.queueMessage("playVideo", JSON.stringify(options), onComplete);
    },
    
    "stopVideo": function(onComplete) {
        if (onComplete==undefined)
            onComplete = function(){};
        
        if (MHShellCalls.video != undefined) {
			MHShellCalls.video.pause();
			MHShellCalls.video.parentNode.removeChild(MHShellCalls.video);
			MHShellCalls.video = undefined;
		}

		if (MHShellCalls.overlayDiv && !MHShellCalls.overlayDiv.removed) {
			MHShellCalls.overlayDiv.removed = true;
			MHShellCalls.overlayDiv.parentNode.removeChild(MHShellCalls.overlayDiv);
		} 

        //MHShellCalls.queueMessage("stopVideo", "", onComplete);
    },
    
    "storeData": function(data,onComplete) {
        if (onComplete==undefined)
            onComplete = function(){};
        
		if (is_uiwebview) {
			MHShellCalls.queueMessage("storeData", data, onComplete);
		} else {
			shellLog('TESTING/MHShellCalls.storeData('+data+')');
			createCookie('mh4data',data,0);
			onComplete();
  		}
    },
    
    "readData": function(callback) {
        if (is_uiwebview) {
	        MHShellCalls.queueMessage("readData", "", callback);
  		} else {
  			var data = readCookie('mh4data');
  			shellLog('TESTING/MHShellCalls.readData() = '+data);
  			callback(data);
  		}
    },
    
    "getStaticForKey": function(data,callback) {
        if (is_uiwebview) {
	        MHShellCalls.queueMessage("getStaticForKey", data, callback);
  		} else {
  			shellLog('TESTING/MHShellCalls.getStaticForKey() = '+data+' (returning "abc")');
  			callback('abc');
  		}
    },
    
    //convenience functions for the above two (don't mix and match!)
    "storeVariable": function(key,value,onComplete) {
        if (onComplete==undefined)
            onComplete = function(){};

		MHShellCalls.readData(function(oldData){
			  var newData = {};
			  
			  if (oldData != "") {
				try {
					newData = JSON.parse(oldData);
				} catch(e) {
				}
				if (newData == undefined || newData == null)
					newData = {};
			  }
			  
			  newData[key] = value;
			  
			  MHShellCalls.storeData(JSON.stringify(newData),onComplete);
		  });
    },
    
    "readVariable": function(key,callback) {
        if (callback==undefined)
            callback = function(){};
            
		MHShellCalls.readData(function(data) {
			var parsed = {};
			try {
				parsed = JSON.parse(data);
			} catch(e) {
			}
			if (parsed==undefined || parsed==null)
				parsed = {};
				
			callback(parsed[key]);
		});
    },
    
    "freezeDisplay": function(onComplete) {
        if (onComplete==undefined)
            onComplete = function(){};

        if (ig.input) 
        	ig.input.enabled = false;
        
        if (is_uiwebview) {
	        MHShellCalls.queueMessage("freezeDisplay", "", onComplete);
	    } else {
	    	onComplete();
	    }
    },
    
    "unfreezeDisplay": function(onComplete,duration) {
        if (onComplete==undefined)
            onComplete = function(){};
        
        if (ig.input) 
	        ig.input.enabled = true;
	        
        if (duration==undefined || duration<=0)
        	duration = .25;
        
        var obj = { duration:duration };
        
        if (is_uiwebview) {
	        MHShellCalls.queueMessage("unfreezeDisplay", JSON.stringify(obj), onComplete);
        } else {
        	onComplete();
        }
    },
    
    "freezeTransition": function(mutation,delay) {
    	if (delay==undefined)
    		delay = 10;
    	
		MHShellCalls.freezeDisplay(function() {
			mutation();
			setTimeout(function() {
				MHShellCalls.unfreezeDisplay();
			},delay);
		});
    },
        
     "loadLocalGame": function(gameName,onComplete) {
        if (onComplete==undefined)
            onComplete = function(){};
        
        if (is_uiwebview) {
	        MHShellCalls.queueMessage("loadLocalGame", gameName, onComplete);
        } else {
        	location.href = '../'+gameName+"/?html="+url_query('html');
        }
    },
    
    "loadLocalGameWithParameterString": function(gameData,onComplete) {
        if (onComplete==undefined)
            onComplete = function(){};
            
        if (is_uiwebview) {
	        MHShellCalls.queueMessage("loadLocalGameWithParameterString", JSON.stringify( gameData ), onComplete);
        } else {
        	location.href = '../'+gameData.gameName+"/?html="+url_query('html')+"&"+gameData.parameterString;
        }
    },

     "giveLootForCheckpoint": function(checkpoint,onComplete) {
        if (onComplete==undefined)
            onComplete = function(){};
        
        if (is_uiwebview) {
	        MHShellCalls.queueMessage("lootCheckpoint", checkpoint, onComplete);
        } else {
        	onComplete();
        }
    },
    

    
    "getLoginToken": function(callback) {
        if (is_uiwebview) {
	        MHShellCalls.queueMessage("getLoginToken", "", callback);
  		} else {
  			callback("debug");
  		}
    },

    "getURLSchemeExists": function(data,callback) {
        if (is_uiwebview) {
	        MHShellCalls.queueMessage("getURLSchemeExists", data, callback);
  		} else {
  			callback("debug");
  		}
    },

    "getDevice": function(callback) {
        if (is_uiwebview) {
	        MHShellCalls.queueMessage("getDevice", "", callback);
  		} else {
  			callback("debug");
  		}
    },

    "getVersion": function(callback) {
        if (is_uiwebview) {
	        MHShellCalls.queueMessage("getVersion", "", callback);
  		} else {
  			callback("debug");
  		}
    },

    "openURLWebview": function(callback,url) {
        if (is_uiwebview) {
	        MHShellCalls.queueMessage("openURLWebview", url, callback);
  		} else {
  			document.location.href = url;
  			//callback("done");
  		}
    },
    
    "openURLExternal": function(callback,url) {
        if (is_uiwebview) {
	        MHShellCalls.queueMessage("openURLExternal", url, callback);
  		} else {
  			document.location.href = url;
  			//callback("done");
  		}
    },
    
    "canTweet": function(callback) {
        MHShellCalls.queueMessage("canTweet", "", callback);
    },

    "canFacebook": function(callback) {
        MHShellCalls.queueMessage("canFacebook", "", callback);
    },
    
    "tweet": function(data,callback) {
        MHShellCalls.queueMessage("tweet", JSON.stringify(data), callback);
		/**
		 Params example:
		 
		 @{ @"message" : @"This is gonna be the tweet", @"picture" : @"bundle-image.png" };
		 */
    },

    "facebook": function(data,callback) {
        MHShellCalls.queueMessage("facebook", JSON.stringify(data), callback);
        
		/*
		 Params example:
		 
		  @{ @"name" : @"Short title", @"picture" : @"http://icon-url.png", @"link" : @"bit.ly/metrics", @"description" : @"  ", @"caption" : @"Long description" };
		 
		 Notes:
		
		 picture: white background, not transparent
		 description: if we don't blank it, it pulls in its own based on our content
		 caption: if blank it uses the link. also, description does not show up in wall post on device in browser or facebook app, so we use caption for that. 100 character limit for caption as well, otherwise it appends a "See more" link
		*/
    },

    "login": function(callback) {
        MHShellCalls.queueMessage("login", "", callback);
    },

    "logout": function(callback) {
        MHShellCalls.queueMessage("logout", "", callback);
    },

	"testObf": function(data,callback) {
		MHShellCalls.queueMessage("testObf", data, callback);
	}

}

function url_query( query ) {
	query = query.replace(/[\[]/,"\\\[").replace(/[\]]/,"\\\]");
	var expr = "[\\?&]"+query+"=([^&#]*)";
	var regex = new RegExp( expr );
	var results = regex.exec( window.location.href );
	if( results !== null ) {
		return results[1];
		return decodeURIComponent(results[1].replace(/\+/g, " "));
	} else {
		return false;
	}
}

function createCookie(name,value,days) {
	if (days) {
		var date = new Date();
		date.setTime(date.getTime()+(days*24*60*60*1000));
		var expires = "; expires="+date.toGMTString();
	}
	else var expires = "";
	document.cookie = name+"="+value+expires+"; path=/";
}

function readCookie(name) {
	var nameEQ = name + "=";
	var ca = document.cookie.split(';');
	for(var i=0;i < ca.length;i++) {
		var c = ca[i];
		while (c.charAt(0)==' ') c = c.substring(1,c.length);
		if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length,c.length);
	}
	return null;
}

function toggleDebug()
	{
	var e = document.getElementById("debug");
	if(e.style.display == "block")
		e.style.display = "none";
	else
		e.style.display = "block";
	}

var resetButton;

function addResetButton(src,width,height)
	{
	var cont = document.getElementById("game")
	if(!cont)
		cont = document.body;//getElementById("body")
	
	var div = document.createElement("div");
	div.setAttribute('id','mobileReset');
	cont.appendChild(div);
	
	var img = document.createElement("img");
	img.setAttribute("src", src);
	img.setAttribute("width", width);
	img.setAttribute("height", height);
	img.setAttribute("alt", "Reset");
	img.setAttribute("onClick", "ig.game.fancyReset();");
	
	div.appendChild(img);
	
	resetButton = div;
	}

function showResetButton()
	{
	if(resetButton)
		resetButton.style.display = "block";
	}

function hideResetButton()
	{
	if(resetButton)
		resetButton.style.display = "none";
	}

function addDebugControls(inputs)
	{
	if(!inputs)
		return;
	
	// get a reference to the debug div (if any)
	var div1 = document.getElementById("debug")
	var div2 = document.getElementById("debugButton")
	if(!div1)
		return;
	
	if(div2)
		{
		// create the debug button
		var form = document.createElement("form");
		div2.appendChild(form);
		
		input = document.createElement("input");
		input.type = "button";
		input.value = "D";
		input.onclick = function() { toggleDebug(); };
		form.appendChild(input);
		}
	
	// create the debug controls
	var form = document.createElement("form");
	div1.appendChild(form);
	
	// append inputs to the form
	for(var i=0; i<inputs.length; i++)
		form.appendChild(inputs[i]);
	}

WebViewCommsLib.eventHandlers['returnedFromBackground'] = function()
{
	MHShellCalls.displayResume();
};
				
document.addEventListener("DOMContentLoaded",function() {
                          
                          /*
                           //read/write data sample
                          MHShellCalls.storeVariable("Mission1-level","over 9000 & change",function() {
                                                     
                                                     MHShellCalls.readVariable("LaunchCount",function(num) {
                                                                               num++;
                                                                               MHShellCalls.storeVariable("LaunchCount",num);
                                                                               });
                                                     });
                          */
                          
                          /*
                           //play sound sample
                           MHShellCalls.playSound("lightbounce/elin_smaka.aiff");
                           */
                          
                          /*
                           //play video sample using callback to loop
                          var doPlay = function() {
                          setTimeout(function() {
                                       MHShellCalls.playVideo("lightbounce/awesome_orange.mp4",doPlay);
                                       }, 500);
                          };
                          doPlay();
                           */
                          });
