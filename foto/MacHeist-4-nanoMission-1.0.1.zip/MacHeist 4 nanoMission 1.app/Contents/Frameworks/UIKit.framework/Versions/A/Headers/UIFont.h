//
//  UIFont.h
//  GreasyPaper
//
//  Created by Karl Baron on 2012/08/08.
//  Copyright (c) 2012年 Karl Baron. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface UIFont : NSObject

+ (UIFont *)systemFontOfSize:(CGFloat)fontSize;
+ (UIFont *)boldSystemFontOfSize:(CGFloat)fontSize;

@end
