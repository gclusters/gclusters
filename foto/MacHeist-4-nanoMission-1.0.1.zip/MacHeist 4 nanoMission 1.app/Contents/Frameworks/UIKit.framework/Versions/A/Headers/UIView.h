//
//  UIView.h
//  GreasyPaper
//
//  Created by Karl Baron on 2012/08/07.
//  Copyright (c) 2012年 Karl Baron. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "GPView.h"
#import "UIColor.h"

@interface UIView : GPView



@end
