//
//  UIDevice.h
//  GreasyPaper
//
//  Created by Karl Baron on 2012/08/07.
//  Copyright (c) 2012年 Karl Baron. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef enum {
    UIDeviceOrientationUnknown,
    UIDeviceOrientationPortrait,
    UIDeviceOrientationPortraitUpsideDown,
    UIDeviceOrientationLandscapeLeft,
    UIDeviceOrientationLandscapeRight,
    UIDeviceOrientationFaceUp,
    UIDeviceOrientationFaceDown
} UIDeviceOrientation;

typedef enum {
    UIUserInterfaceIdiomPhone,
    UIUserInterfaceIdiomPad,
    UIUserInterfaceIdiomDesktop,
} UIUserInterfaceIdiom;

@interface UIDevice : NSObject

+(UIDevice*) currentDevice;

-(NSString*) systemVersion;
-(NSString*) model;
-(UIUserInterfaceIdiom) userInterfaceIdiom;
@end
