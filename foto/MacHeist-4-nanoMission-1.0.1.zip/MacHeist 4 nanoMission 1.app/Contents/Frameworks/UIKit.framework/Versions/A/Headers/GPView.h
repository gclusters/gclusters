//
//  GPView.h
//  GreasyPaper
//
//  Created by Karl Baron on 2012/08/08.
//  Copyright (c) 2012年 Karl Baron. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "UIColor.h"


enum {
    UIViewAutoresizingNone                 = 0,
    UIViewAutoresizingFlexibleLeftMargin   = 1 << 0,
    UIViewAutoresizingFlexibleWidth        = 1 << 1,
    UIViewAutoresizingFlexibleRightMargin  = 1 << 2,
    UIViewAutoresizingFlexibleTopMargin    = 1 << 3,
    UIViewAutoresizingFlexibleHeight       = 1 << 4,
    UIViewAutoresizingFlexibleBottomMargin = 1 << 5
};
typedef NSUInteger UIViewAutoresizing;

typedef enum {
    UIViewContentModeScaleToFill,
    UIViewContentModeScaleAspectFit,
    UIViewContentModeScaleAspectFill,
    UIViewContentModeRedraw,
    UIViewContentModeCenter,
    UIViewContentModeTop,
    UIViewContentModeBottom,
    UIViewContentModeLeft,
    UIViewContentModeRight,
    UIViewContentModeTopLeft,
    UIViewContentModeTopRight,
    UIViewContentModeBottomLeft,
    UIViewContentModeBottomRight,
} UIViewContentMode;

typedef enum {
    UIViewAnimationCurveEaseInOut,
    UIViewAnimationCurveEaseIn,
    UIViewAnimationCurveEaseOut,
    UIViewAnimationCurveLinear
} UIViewAnimationCurve;

typedef enum {
    UIViewAnimationTransitionNone,
    UIViewAnimationTransitionFlipFromLeft,
    UIViewAnimationTransitionFlipFromRight,
    UIViewAnimationTransitionCurlUp,
    UIViewAnimationTransitionCurlDown,
} UIViewAnimationTransition;

enum {
    UIViewAnimationOptionLayoutSubviews            = 1 <<  0,		// not currently supported
    UIViewAnimationOptionAllowUserInteraction      = 1 <<  1,
    UIViewAnimationOptionBeginFromCurrentState     = 1 <<  2,
    UIViewAnimationOptionRepeat                    = 1 <<  3,
    UIViewAnimationOptionAutoreverse               = 1 <<  4,
    UIViewAnimationOptionOverrideInheritedDuration = 1 <<  5,		// not currently supported
    UIViewAnimationOptionOverrideInheritedCurve    = 1 <<  6,		// not currently supported
    UIViewAnimationOptionAllowAnimatedContent      = 1 <<  7,		// not currently supported
    UIViewAnimationOptionShowHideTransitionViews   = 1 <<  8,		// not currently supported
    
    UIViewAnimationOptionCurveEaseInOut            = 0 << 16,
    UIViewAnimationOptionCurveEaseIn               = 1 << 16,
    UIViewAnimationOptionCurveEaseOut              = 2 << 16,
    UIViewAnimationOptionCurveLinear               = 3 << 16,
    
    UIViewAnimationOptionTransitionNone            = 0 << 20,		// not currently supported
    UIViewAnimationOptionTransitionFlipFromLeft    = 1 << 20,		// not currently supported
    UIViewAnimationOptionTransitionFlipFromRight   = 2 << 20,		// not currently supported
    UIViewAnimationOptionTransitionCurlUp          = 3 << 20,		// not currently supported
    UIViewAnimationOptionTransitionCurlDown        = 4 << 20,		// not currently supported
};
typedef NSUInteger UIViewAnimationOptions;

@interface GPView : NSObject
{
    CGRect _frame;
}

@property (nonatomic, strong) NSView* macView;
@property (nonatomic, weak) GPView* superview;
@property (nonatomic, strong) NSMutableArray* subviews;
@property (nonatomic, assign) CGRect bounds;
@property (nonatomic, assign) CGRect frame;
@property (nonatomic) CGPoint center;
@property (nonatomic, copy) UIColor *backgroundColor;
@property (nonatomic) UIViewAutoresizing autoresizingMask;
@property (nonatomic) BOOL userInteractionEnabled;
@property (nonatomic) float alpha;
@property (nonatomic) BOOL opaque;
@property (nonatomic) NSInteger tag;
@property (nonatomic) BOOL multipleTouchEnabled;
@property (nonatomic) BOOL scrollEnabled;
@property (nonatomic) BOOL bounces;
@property (nonatomic) BOOL hidden;
@property (nonatomic) CGAffineTransform transform;
@property (nonatomic) CGFloat contentScaleFactor;

- (id)init;
- (id)initWithFrame:(CGRect)theFrame;
- (void)addSubview:(GPView *)subview;
- (void)removeFromSuperview;
-(CALayer*)layer;
-(void)sizeToFit;
-(GPView*)viewWithTag:(NSInteger)aTag;
-(void)setNeedsDisplay;

+ (void)beginAnimations:(NSString *)animationID context:(void *)context;
+ (void)commitAnimations;
+ (void)setAnimationBeginsFromCurrentState:(BOOL)beginFromCurrentState;
+ (void)setAnimationCurve:(UIViewAnimationCurve)curve;
+ (void)setAnimationDelay:(NSTimeInterval)delay;
+ (void)setAnimationDelegate:(id)delegate;
+ (void)setAnimationDidStopSelector:(SEL)selector;
+ (void)setAnimationDuration:(NSTimeInterval)duration;
+ (void)setAnimationRepeatAutoreverses:(BOOL)repeatAutoreverses;
+ (void)setAnimationRepeatCount:(float)repeatCount;
+ (void)setAnimationTransition:(UIViewAnimationTransition)transition forView:(GPView *)view cache:(BOOL)cache;
+ (void)setAnimationWillStartSelector:(SEL)selector;
+ (BOOL)areAnimationsEnabled;
+ (void)setAnimationsEnabled:(BOOL)enabled;


// mac passthru
- (NSBitmapImageRep *)bitmapImageRepForCachingDisplayInRect:(NSRect)aRect;
- (void)cacheDisplayInRect:(NSRect)rect toBitmapImageRep:(NSBitmapImageRep *)bitmapImageRep;


@end
