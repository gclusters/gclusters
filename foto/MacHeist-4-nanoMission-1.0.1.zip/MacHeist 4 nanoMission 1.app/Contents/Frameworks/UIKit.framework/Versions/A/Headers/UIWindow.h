//
//  UIWindow.h
//  GreasyPaper
//
//  Created by Karl Baron on 2012/08/07.
//  Copyright (c) 2012年 Karl Baron. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "UIScreen.h"
#import "GPView.h"
#import "UIViewController.h"

@interface UIWindow : GPView

@property (nonatomic, strong) UIScreen* screen;
@property (nonatomic, strong) UIViewController* rootViewController;

- (id)initWithFrame:(CGRect)theFrame;
- (void)makeKeyAndVisible;

@end
