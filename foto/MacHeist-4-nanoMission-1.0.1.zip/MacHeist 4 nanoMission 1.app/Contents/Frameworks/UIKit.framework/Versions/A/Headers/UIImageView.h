//
//  UIImageView.h
//  GreasyPaper
//
//  Created by Karl Baron on 2012/08/08.
//  Copyright (c) 2012年 Karl Baron. All rights reserved.
//

#import "GPView.h"
#import "UIImageAppKitIntegration.h"

@interface UIImageView : GPView

-(id)initWithImage:(UIImage*)image;

@end
