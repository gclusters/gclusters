//
//  GreasyPaperOptions.h
//  GreasyPaper
//
//  Created by Karl Baron on 2012/08/07.
//  Copyright (c) 2012年 Karl Baron. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface GreasyPaperOptions : NSObject

@property (nonatomic,strong) NSWindow* mainWindow;
@property (nonatomic,strong) NSView* mainView;

+(GreasyPaperOptions*) sharedOptions;

@end
