//
//  UIApplication.h
//  GreasyPaper
//
//  Created by Karl Baron on 2012/08/07.
//  Copyright (c) 2012年 Karl Baron. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "UIDevice.h"
#import "UIWindow.h"

typedef enum {
    UIInterfaceOrientationPortrait           = UIDeviceOrientationPortrait,
    UIInterfaceOrientationPortraitUpsideDown = UIDeviceOrientationPortraitUpsideDown,
    UIInterfaceOrientationLandscapeLeft      = UIDeviceOrientationLandscapeRight,
    UIInterfaceOrientationLandscapeRight     = UIDeviceOrientationLandscapeLeft
} UIInterfaceOrientation;


#define UIInterfaceOrientationIsPortrait(orientation) \
((orientation) == UIInterfaceOrientationPortrait || \
(orientation) == UIInterfaceOrientationPortraitUpsideDown)

#define UIInterfaceOrientationIsLandscape(orientation) \
((orientation) == UIInterfaceOrientationLandscapeLeft || \
(orientation) == UIInterfaceOrientationLandscapeRight)

@interface UIApplication : NSObject

+(UIApplication*) sharedApplication;

@property (nonatomic, strong) UIWindow* keyWindow;
@property (nonatomic) BOOL networkActivityIndicatorVisible;
@property (nonatomic) UIInterfaceOrientation statusBarOrientation;
@property (nonatomic, readonly) NSTimeInterval statusBarOrientationAnimationDuration;

-(id)delegate;

- (BOOL)openURL:(NSURL *)url;
- (BOOL)canOpenURL:(NSURL *)URL;

@end
