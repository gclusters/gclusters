//
//  UILabel.h
//  GreasyPaper
//
//  Created by Karl Baron on 2012/08/08.
//  Copyright (c) 2012年 Karl Baron. All rights reserved.
//

#import "GPView.h"
#import "UIFont.h"

@interface UILabel : GPView

@property (nonatomic, strong) NSTextField* macTextView;

@property (nonatomic, copy) NSString *text;
@property (nonatomic, strong) UIFont *font;
@property (nonatomic, strong) UIColor *textColor;
@property (nonatomic, strong) UIColor *highlightedTextColor;
@property (nonatomic, strong) UIColor *shadowColor;
@property (nonatomic) CGSize shadowOffset;
//@property (nonatomic) UITextAlignment textAlignment;
//@property (nonatomic) UILineBreakMode lineBreakMode;
@property (nonatomic, getter=isEnabled) BOOL enabled;
@property (nonatomic) NSInteger numberOfLines;					// currently only supports 0 or 1
//@property (nonatomic) UIBaselineAdjustment baselineAdjustment;	// not implemented
@property (nonatomic) BOOL adjustsFontSizeToFitWidth;			// not implemented
@property (nonatomic) CGFloat minimumFontSize;					// not implemented
@property (nonatomic, getter=isHighlighted) BOOL highlighted;

@end
