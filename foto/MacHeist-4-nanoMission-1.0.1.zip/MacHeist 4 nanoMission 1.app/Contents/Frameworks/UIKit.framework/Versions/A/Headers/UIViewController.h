//
//  UIViewController.h
//  GreasyPaper
//
//  Created by Karl Baron on 2012/08/07.
//  Copyright (c) 2012年 Karl Baron. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "UIView.h"

@interface UIViewController : NSObject

@property (nonatomic, strong) UIView* view;

-(void)loadView;
-(void)viewDidUnload;
- (void)viewDidAppear:(BOOL)animated;
-(void)viewWillDisappear:(BOOL)animated;
- (void)viewDidLoad;

- (void)presentModalViewController:(UIViewController *)modalViewController animated:(BOOL)animated;
- (void)dismissModalViewControllerAnimated:(BOOL)animated;


@end
